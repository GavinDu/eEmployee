//var parentFolder="N:/projects/SSlib5/renders/testViews";
//var baseFolder="N:/projects/SSlib5/renders/testViews/jsp";
//var baseHost="";
var tmpl = parentFolder + "/templates/layouts/defaultLayout.jsp";
var base = {
   _httpHeader: parentFolder + "/templates/layouts/defaultHttpHeader.jsp",
    title: "DHVC",
    __header: parentFolder + "/templates/layouts/defaultHeader.jsp",
    _menu: parentFolder + "/templates/layouts/defaultMenu.jsp",
    _footer: parentFolder + "/templates/layouts/defaultFooter.jsp",
    _jsBottom: parentFolder + "/templates/layouts/defaultScript.jsp",
};

var tmpl_china = parentFolder + "/templates/layouts/defaultLayout_china.jsp";
var base_china = {
    _httpHeaderChina: parentFolder + "/templates/layouts/defaultHttpHeader.jsp",
    titleChina: "丹华",
    __headerChina: parentFolder + "/templates/layouts/defaultHeader.jsp",
    _menuChina: parentFolder + "/templates/layouts/defaultMenu_chinese.jsp",
    _footerChina: parentFolder + "/templates/layouts/defaultFooter.jsp",
    _jsBottomChina: parentFolder + "/templates/layouts/defaultScript.jsp"
};

var tmpl_mb = parentFolder + "/templates/layouts/defaultLayout_mb.jsp";
var base_mb = {
    _httpHeaderMb: parentFolder + "/templates/layouts/defaultHttpHeader_mb.jsp",
    title: "DHVC_mb",
    __headerMb: parentFolder + "/templates/layouts/defaultHeader_mb.jsp",
    _menuMb: parentFolder + "/templates/layouts/defaultMenu_mb.jsp",
    _footerMb: parentFolder + "/templates/layouts/defaultFooter_mb.jsp",
    _jsBottomMb: parentFolder + "/templates/layouts/defaultScript_mb.jsp",
};


var templates = {

    "veiwpages/viewerror": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/public/error404.jsp";
       def.title = "error";
       def.csses = [
           //baseHost + '/resources/app/css/star.css'
       ];
       def.scripts = [
           //baseHost + "/resources/app/js/star.js"
       ];
       return def;
    })(),

    "veiwpages/viewUShome": (function () {
        var def = clone(base);
        def.__body = parentFolder + "/pages/USHome.jsp";
        def.title = "DHVC-home";
        def.csses = [
            baseHost + '/resources/app/css/public/animate.min.css',
            baseHost + '/resources/app/css/style.css',
            baseHost + '/resources/libs/fullpage/fullpage.css',
            baseHost + '/resources/app/css/USHome.css'
        ];
        def.scripts = [
            baseHost + "/resources/libs/fullpage/scrolloverflow.js",
            baseHost + "/resources/libs/fullpage/fullpage.js",
            baseHost + "/resources/app/js/USHome.js"

        ];
        return def;
    })(),
   "veiwpages/viewUSAbout": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/USAbout.jsp";
       def.title = "DHVC-about";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USAbout.css'
       ];
       def.scripts = [
          /* baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/USAbout.js"
       ];
       return def;
   })(),

    "veiwpages/viewUSNews": (function () {
        var def = clone(base_mb);
        def.__body = parentFolder + "/pages/USNews.jsp";
        def.title = "DHVC-news";
        def.csses = [
            baseHost + '/resources/app/css/style.css',
            baseHost + '/resources/app/css/USNews.css'
        ];
        def.scripts = [
            baseHost + "/resources/app/js/USNews.js"
        ];
        return def;
    })(),

   "veiwpages/viewUSportfolios": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/USPortfolios.jsp";
       def.title = "DHVC-portfolio";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USPortfolios.css'
       ];
       def.scripts = [
          /* baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/USPortfolios.js"
       ];
       return def;
   })(),

   "veiwpages/viewUSteams": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/USTeam.jsp";
       def.title = "DHVC-Team";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USTeam.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/USTeam.js"
       ];
       return def;
   })(),

   "veiwpages/viewUSevents": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/USEvents.jsp";
       def.title = "DHVC-news";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USEvents.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/public/pagination.min.js",
           baseHost + "/resources/app/js/USEvents.js"
       ];
       return def;
   })(),

   //没有用到
   "viewspages/USNewsDetails": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/USNewsDetails.jsp";
       def.title = "DHVC-news";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USNewsDetails.css'
       ];
       def.scripts = [
           baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",
           baseHost + "/resources/app/js/USNewsDetails.js"
       ];
       return def;
   })(),

   "veiwpages/viewUSContact": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/USContact.jsp";
       def.title = "DHVC-contact";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USContact.css'
       ];
       def.scripts = [
           baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",
           baseHost + "/resources/app/js/USContact.js"
       ];
       return def;
   })(),

   "veiwpages/personDetail": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/personDetail.jsp";
       def.title = "DHVC-person";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/personDetail.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/personDetail.js"
       ];
       return def;
   })()
};

var templates_chinese = {
   "veiwpages/viewerror": (function () {
       var def = clone(base);
       def.__body = parentFolder + "/pages/public/error404.jsp";
       def.title = "error";
       def.csses = [
           //baseHost + '/resources/app/css/star.css'
       ];
       def.scripts = [
           //baseHost + "/resources/app/js/star.js"
       ];
       return def;
   })(),

    "veiwpages/viewCHhome": (function () {
        var def = clone(base_china);
        def.__body = parentFolder + "/pages/chineseHome.jsp";
        def.title = "丹华-首页";
        def.csses = [
            baseHost + '/resources/app/css/public/animate.min.css',
            baseHost + '/resources/app/css/style.css',
            baseHost + '/resources/libs/fullpage/fullpage.css',
            baseHost + '/resources/app/css/USHome.css'
        ];
        def.scripts = [
            baseHost + "/resources/libs/fullpage/scrolloverflow.js",
            baseHost + "/resources/libs/fullpage/fullpage.js",
            baseHost + "/resources/app/js/USHome.js"

        ];
        return def;
    })(),

   "veiwpages/viewCHAbout": (function () {
       var def = clone(base_china);
       def.__body = parentFolder + "/pages/chineseAbout.jsp";
       def.title = "丹华-关于我们";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USAbout.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/USAbout.js"
       ];
       return def;
   })(),

   "veiwpages/viewCHContact": (function () {
       var def = clone(base_china);
       def.__body = parentFolder + "/pages/chineseContact.jsp";
       def.title = "联系我们";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USContact.css'
       ];
       def.scripts = [
           baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",
           baseHost + "/resources/app/js/USContact.js"
       ];
       return def;
   })(),

   "veiwpages/viewCHteams": (function () {
       var def = clone(base_china);
       def.__body = parentFolder + "/pages/chineseTeam.jsp";
       def.title = "丹华-团队信息";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USTeam.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/USTeam.js"
       ];
       return def;
   })(),

   "veiwpages/personCHDetail": (function () {
       var def = clone(base_china);
       def.__body = parentFolder + "/pages/chinesePersonDetail.jsp";
       def.title = "丹华-成员信息";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/personDetail.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/personDetail.js"
       ];
       return def;
   })(),

   "veiwpages/viewCHevents": (function () {
       var def = clone(base_china);
       def.__body = parentFolder + "/pages/chineseEvents.jsp";
       def.title = "丹华-事件";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USEvents.css'
       ];
       def.scripts = [
           /*baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/public/pagination.min.js",
           baseHost + "/resources/app/js/USEvents.js"
       ];
       return def;
   })(),
   "veiwpages/viewCHportfolios": (function () {
       var def = clone(base_china);
       def.__body = parentFolder + "/pages/chinesePortfolios.jsp";
       def.title = "丹华-被投企业";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USPortfolios.css'
       ];
       def.scripts = [
          /* baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app.js",*/
           baseHost + "/resources/app/js/USPortfolios.js"
       ];
       return def;
   })()
};

var templates_mb = {

    "veiwpages/viewerror_mb": (function () {
        var def = clone(base_mb);
        def.__body = parentFolder + "/pages/public/error404_mb.jsp";
        def.title = "error";
        def.csses = [
            //baseHost + '/resources/app/css/star.css'
        ];
        def.scripts = [
            //baseHost + "/resources/app/js/star.js"
        ];
        return def;
    })(),

    "veiwpages/viewUShome_mb": (function () {
        var def = clone(base_mb);
        def.__body = parentFolder + "/pages/USHome_mb.jsp";
        def.title = "DHVC-home";
        def.csses = [
            baseHost + '/resources/app/css/public/animate.min.css',
            baseHost + '/resources/libs/fullpage/fullpage.css',
            baseHost + '/resources/app/css/style.css',
            baseHost + '/resources/app/css/USHome_mb.css'
        ];
        def.scripts = [
            baseHost + "/resources/libs/fullpage/scrolloverflow.js",
            baseHost + "/resources/libs/fullpage/fullpage.js",
            baseHost + "/resources/app/js/USHome_mb.js"


        ];
        return def;
    })(),

    "veiwpages/viewUSAbout_mb": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/USAbout_mb.jsp";
       def.title = "DHVC-about";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USAbout_mb.css'
       ];
       def.scripts = [
           // baseHost + "/resources/app/js/particles.min.js",
           // baseHost + "/resources/app/js/app_mb.js",
           baseHost + "/resources/app/js/USAbout_mb.js"
       ];
       return def;
    })(),

    "veiwpages/viewUSNews_mb": (function () {
        var def = clone(base_mb);
        def.__body = parentFolder + "/pages/USNews_mb.jsp";
        def.title = "DHVC-news";
        def.csses = [
            baseHost + '/resources/app/css/style.css',
            baseHost + '/resources/app/css/USNews_mb.css'
        ];
        def.scripts = [
            baseHost + "/resources/app/js/USNews_mb.js"
        ];
        return def;
    })(),

    "veiwpages/viewUSportfolios_mb": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/USPortfolios_mb.jsp";
       def.title = "DHVC-portfolio";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USPortfolios_mb.css'
       ];
       def.scripts = [
           // baseHost + "/resources/app/js/particles.min.js",
           // baseHost + "/resources/app/js/app_mb.js",
           baseHost + "/resources/app/js/USPortfolios_mb.js"
       ];
       return def;
    })(),

    "veiwpages/viewUSteams_mb": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/USTeam_mb.jsp";
       def.title = "DHVC-Team";
       def.csses = [
           // baseHost + '/resources/app/css/public/jquery.mobile.min.css',
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USTeam_mb.css'
       ];
       def.scripts = [
           baseHost + "/resources/app/js/public/jquery.mobile.min.js",
           // baseHost + "/resources/app/js/particles.min.js",
           // baseHost + "/resources/app/js/app_mb.js",
           baseHost + "/resources/app/js/USTeam_mb.js"
       ];
       return def;
    })(),

    "veiwpages/viewUSevents_mb": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/USEvents_mb.jsp";
       def.title = "DHVC-Ideas";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/public/dropload.css',
           baseHost + '/resources/app/css/USEvents_mb.css'
       ];
       def.scripts = [
           // baseHost + "/resources/app/js/particles.min.js",
           // baseHost + "/resources/app/js/app_mb.js",
           baseHost + "/resources/app/js/public/pagination.min.js",
           baseHost + "/resources/app/js/public/dropload.min.js",
           baseHost + "/resources/app/js/USEvents_mb.js"
       ];
       return def;
    })(),

    "viewspages_mb/USNewsDetails": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/USNewsDetails_mb.jsp";
       def.title = "DHVC-Ideas";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USNewsDetails_mb.css'
       ];
       def.scripts = [
           // baseHost + "/resources/app/js/particles.min.js",
           baseHost + "/resources/app/js/app_mb.js"
           // baseHost + "/resources/app/js/USNewsDetails_mb.js"
       ];
       return def;
    })(),

    "veiwpages/viewUSContact_mb": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/USContact_mb.jsp";
       def.title = "DHVC-contact";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/USContact_mb.css'
       ];
       def.scripts = [
           // baseHost + "/resources/app/js/particles.min.js",
           // baseHost + "/resources/app/js/app_mb.js",
           baseHost + "/resources/app/js/USContact_mb.js"
       ];
       return def;
    })(),

    "veiwpages/personDetail_mb": (function () {
       var def = clone(base_mb);
       def.__body = parentFolder + "/pages/personDetail_mb.jsp";
       def.title = "DHVC-person";
       def.csses = [
           baseHost + '/resources/app/css/style.css',
           baseHost + '/resources/app/css/personDetail_mb.css'
       ];
       def.scripts = [
           // baseHost + "/resources/app/js/particles.min.js",
           // baseHost + "/resources/app/js/app_mb.js",
           baseHost + "/resources/app/js/personDetail_mb.js"
       ];
       return def;
    })()
};

buildAll(tmpl_mb, templates_mb, baseFolder);
buildAll(tmpl_china, templates_chinese, baseFolder);
buildAll(tmpl, templates, baseFolder);

