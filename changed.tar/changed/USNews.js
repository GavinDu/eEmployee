$(function () {
    $(".navList li:nth-of-type(1)").addClass('active');
})